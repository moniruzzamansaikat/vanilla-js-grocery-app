const form = document.querySelector('form#add-form')
const input = document.querySelector('form input[type="text"]')
const listContainer = document.querySelector('#list-container')
const filterBox = document.querySelector('.filter-box')
const searchInput = document.querySelector('.filter-box input')

// base case for filter box
filterBox.style.display = 'none'

// counter for items
let count = 0
const MX = 1000

form.addEventListener('submit', add)

function add(e) {
    e.preventDefault()
    const userVal = input.value
    if (userVal && count < MX) {

        const li = document.createElement('li')
        li.classList.add('item')
        li.innerHTML = ` 
            <div>
                ${userVal}
            </div>
            <button class="del" title="Delete">
                <img src="./img/Knob Remove Red.png" alt="">
            </button> 
        `
        listContainer.appendChild(li)

        // clear the input box
        input.value = ''
        count++
    } else {
        if (!userVal) {
            alert('Please write something')
        } else {
            alert('Cooldown 😇😇')
        }
    }

    callMe()
}

// Delete every single item
function callMe() { 
    if (count > 0) {
        document.querySelector('li.no-item').style.display = 'none'
        filterBox.style.display = 'block'
    }
    document.querySelectorAll('button.del')
        .forEach(item => {
            item.onclick = () => {
                item.parentElement.remove()
                count--
                if (count > 0) {
                    document.querySelector('li.no-item').style.display = 'none'
                    filterBox.style.display = 'block'
                } else {
                    document.querySelector('li.no-item').style.display = 'block'
                    filterBox.style.display = 'none'
                }
            }
        })

    
    // search features
    searchInput.oninput = e => {
        document.querySelectorAll('li.item:not(.no-item)').forEach(liItem => {
            if (liItem.firstElementChild.innerHTML.trim().toLowerCase().indexOf(e.target.value.trim().toLowerCase()) === -1) {
                liItem.style.display = 'none'
            } else{
                liItem.style.display = 'flex'
            }
        }) 
    }

} 